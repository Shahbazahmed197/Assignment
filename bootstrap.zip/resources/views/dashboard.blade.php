@extends('layouts.master')

@section('title')
    Dashboard
@endsection

@section('content')
<div class="container-fluid">
    <div class="nk-content-inner">
        <div class="nk-content-body">
            <p>Starter page for general layout.</p>
        </div>
    </div>
</div>
@endsection
