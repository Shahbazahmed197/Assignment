<?php $__env->startSection('title'); ?>
    Edit Product
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <div class="p-4 my-4">
                        <div id="responseMessage"></div>
                        <form id="productupdateForm" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <!-- Product Name -->
                            <div class="form-group">
                                <label for="productName">Product Name</label>
                                <input type="text" class="form-control" id="productName"
                                    name="name" required>
                                    <input type="text" class="form-control" id="productid"
                                    name="product_id" hidden required>
                            </div>

                            <!-- Product Description -->
                            <div class="form-group ">
                                <label for="productDescription">Product Description</label>
                                <textarea class="form-control" id="productDescription" name="description" rows="4" required>
                                    
                                </textarea>
                            </div>

                            <!-- Product Categories (Multiple Select) -->
                            <div class="form-group">
                                <label class="form-label">Select2 Multiple</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" multiple="multiple" data-placeholder="Select Multiple options">
                                        <option value="default_option">Default Option</option>
                                        <option value="option_select_name">Option select name</option>
                                        <option value="option_select_name">Option select name</option>
                                        <option value="option_select_name">Option select name</option>
                                        <option value="option_select_name">Option select name</option>
                                        <option value="option_select_name">Option select name</option>
                                        <option value="option_select_name">Option select name</option>
                                        <option value="option_select_name">Option select name</option>
                                        <option value="option_select_name">Option select name</option>
                                        <option value="option_select_name">Option select name</option>
                                        <option value="option_select_name">Option select name</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Product Images (Multiple Uploads) -->
                            <div class="form-group">
                                <label for="productImages">Product Images</label>
                                <div class="upload-zone" data-accepted-files="image/*">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">Drag and drop file</span>
                                        <span class="dz-message-or">or</span>
                                        <button type="button" class="btn btn-primary">SELECT</button>
                                    </div>
                                </div>
                            </div>

                            <!-- Submit Button -->
                            <button type="button" class="btn btn-primary text-dark" onclick="updateProductForm()">
                                Update Product</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.8.1/css/bootstrap-select.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.8.1/js/bootstrap-select.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelAssignment-Mid-Level\resources\views/products/edit.blade.php ENDPATH**/ ?>