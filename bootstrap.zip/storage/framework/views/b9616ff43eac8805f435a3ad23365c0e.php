<?php $__env->startSection('title'); ?>
    Add Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <div class="container my-4">
                        <div id="responseMessage"></div>
                        <form id="categoryForm" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <!-- Category Name -->
                            <div class="form-group">
                                <label for="CategoryName">Category Name</label>
                                <input type="text" class="form-control" id="CategoryName" name="name" required>
                                <div class="invalid-feedback" id="category_name_error"></div>
                            </div>

                            <!-- Submit Button -->
                            <button type="button" class="btn btn-primary text-dark" onclick="submitcategoryForm()">Add
                                Category</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelAssignment-Mid-Level\resources\views/category/create.blade.php ENDPATH**/ ?>