<div class="card-aside card-aside-left user-aside toggle-slide toggle-slide-left toggle-break-lg" data-content="userAside" data-toggle-screen="lg" data-toggle-overlay="true">
    <div class="card-inner-group" data-simplebar>
        <div class="card-inner">
            <div class="user-card">
                <div class="user-avatar bg-primary">
                    <span>AB</span>
                </div>
                <div class="user-info">
                    <span class="lead-text"><?php echo e($user->name); ?></span>
                    <span class="sub-text"><?php echo e($user->email); ?></span>
                </div>
                <div class="user-action">
                    <div class="dropdown">
                        <a class="btn btn-icon btn-trigger mr-n2" data-toggle="dropdown" href="#"><em class="icon ni ni-more-v"></em></a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <ul class="link-list-opt no-bdr">
                                <li data-toggle="modal" data-target="#profile-edit"><a ><em class="icon ni ni-camera-fill"></em><span>Change Photo</span></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div><!-- .user-card -->
        </div><!-- .card-inner -->

        <div class="card-inner p-0">
            <ul class="link-list-menu">
                <li><a class="<?php echo e(Route::is('profile.index') ? 'active' : ''); ?>" href="<?php echo e(route('profile.index')); ?>"><em class="icon ni ni-user-fill-c"></em><span>Personal Infomation</span></a></li>
                 <li><a class="<?php echo e(Route::is('setting.index') ? 'active' : ''); ?>" href="<?php echo e(route('setting.index')); ?>"><em class="icon ni ni-lock-alt-fill"></em><span>Security Settings</span></a></li>
            </ul>
        </div><!-- .card-inner -->
    </div><!-- .card-inner-group -->
</div><!-- card-aside -->
<div class="modal fade" role="dialog" id="change-photo">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            <div class="modal-body modal-body-lg">
                <h5 class="title">Update Profile</h5>
             <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div><!-- .modal-body -->
        </div><!-- .modal-content -->
    </div><!-- .modal-dialog -->
</div><!-- .modal -->
<?php /**PATH D:\LaravelAssignment-Mid-Level\resources\views/profile/partials/aside.blade.php ENDPATH**/ ?>