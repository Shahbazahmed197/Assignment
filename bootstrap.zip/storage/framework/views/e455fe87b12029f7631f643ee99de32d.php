<section>

        <form method="POST" id="updatePasswordForm">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <!--Current Password -->
        <div class="form-group">
            <label class="form-label" for="current_password">Current Password</label>
            <div class="form-control-wrap">
                <a tabindex="-1" href="#" class="form-icon form-icon-right passcode-switch lg"
                    data-target="password">
                    <em class="passcode-icon icon-show icon ni ni-eye"></em>
                    <em class="passcode-icon icon-hide icon ni ni-eye-off"></em>
                </a>
                <input type="password" required name="current_password" class="form-control form-control-lg"
                    id="password" value="<?php echo e(old('current_password')); ?>" placeholder="Enter your current password" aria-invalid="false">
                            </div>
        </div>

        <!-- New Password -->
        <div class="form-group">
            <label class="form-label" for="password">New Password</label>
            <div class="form-control-wrap">
                <a tabindex="-1" href="#" class="form-icon form-icon-right passcode-switch lg"
                    data-target="new_password">
                    <em class="passcode-icon icon-show icon ni ni-eye"></em>
                    <em class="passcode-icon icon-hide icon ni ni-eye-off"></em>
                </a>
                <input type="password" required name="password" value="<?php echo e(old('password')); ?>" class="form-control form-control-lg" id="new_password"
                    placeholder="Enter your new password">
            </div>
        </div>
        <!--Confirm New Password -->
        <div class="form-group">
            <label class="form-label" for="password_confirmation">Confirm New Password</label>
            <div class="form-control-wrap">
                <a tabindex="-1" href="#" class="form-icon form-icon-right passcode-switch lg"
                    data-target="password_confirmation">
                    <em class="passcode-icon icon-show icon ni ni-eye"></em>
                    <em class="passcode-icon icon-hide icon ni ni-eye-off"></em>
                </a>
                <input type="password" required name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" class="form-control form-control-lg"
                    id="password_confirmation" placeholder="Enter your new password again">
                </div>
        </div>

        <div class="flex items-center gap-4">
            <div class="form-group">
                <button type="button" class="btn btn-lg btn-primary submit-btn " id="update-password-button"> Change Password</button>
            </div>

            
        </div>
    </form>
    <script>
    $(document).ready(function() {
            NioApp.Passcode('.passcode-switch');
    });
    </script>

</section>
<?php /**PATH D:\LaravelAssignment-Mid-Level\resources\views/profile/partials/update-password-form.blade.php ENDPATH**/ ?>