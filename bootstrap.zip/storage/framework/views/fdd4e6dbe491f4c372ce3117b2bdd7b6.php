<?php $__env->startSection('content'); ?>
  <div class="container">
    <span>
        <a class="btn btn-info"  href="<?php echo e(route('web-category.index')); ?>">
             Back</a>
    </span><br>
    <strong class="py-3"> Products</strong>
    <div class="row">
      <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
          <div class="card">
            <div class="card-body">
                <img width="100px" height="100px" src="<?php echo e(asset('storage/'.$product->images[0]->path)); ?>" alt="">
              <h5 class="card-title"><?php echo e($product->name); ?></h5>
              <a href="<?php echo e(route('web-product.show',$product->id)); ?>" class="btn btn-primary">View Detail</a>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelAssignment-Mid-Level\resources\views/front/products.blade.php ENDPATH**/ ?>