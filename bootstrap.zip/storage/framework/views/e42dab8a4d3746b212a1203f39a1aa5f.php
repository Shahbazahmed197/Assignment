<?php $__env->startSection('content'); ?>
    <div class="container">
        <span>
            <a class="btn btn-info" href="<?php echo e(route('web-category.index')); ?>">
                Back</a>
        </span><br>
        <div class="row">
            <div class="col-md-2 mb-4"></div>
            <div class="col-md-8 mb-4">
                <div class="card">
                    <div class="card-body">
                        <div id="imagePreview" class="d-flex flex-wrap pt-3">
                            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e(asset('storage/' . $image->path)); ?>" class="img-thumbnail mr-2 mb-2"
                                    style="max-height: 100px;">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <h5 class="card-title"><?php echo e($product->name); ?></h5>
                        <h5 class="card-title">Description:</h5>
                        <p class="text-dark"><?php echo e($product->description); ?></p>
                        <!-- Comment Section -->
                        <div class="comments-section py-5">
                            <h5>Comments and Feedback</h5>

                            <!-- Display existing comments -->
                            <div id="commentContainer">
                            <?php $__currentLoopData = $product->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="comment py-3">
                                    <span><strong> <?php echo e($comment->user->name); ?>&nbsp;</strong></span><span><small>
                                            <?php echo e($comment->created_at->format('d M, Y')); ?></small></span>
                                    <p><?php echo e($comment->rating); ?> Stars</p>
                                    <p><?php echo e($comment->content); ?></p>

                                </div>
                                <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                            <h5 class="text-center pt-3">Add a Comment</h5>
                            <!-- Comment Form -->
                            <form action="<?php echo e(route('comment.store')); ?>" method="POST" class="mt-4" id="commentForm">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <div class="form-group">
                                    <label for="rating">Rating (1-5)</label>
                                    <input type="number" name="rating" id="rating" class="form-control" min="1"
                                        max="5" step="1" required>
                                </div>
                                <div class="form-group">
                                    <label for="content">Write your comment here</label>
                                    <textarea name="comment" id="content" class="form-control" rows="5" required></textarea>
                                </div>
                                <button type="button" class="btn btn-primary text-dark "
                                    onclick="submitcommentForm()">Submit Comment</button>
                            </form>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelAssignment-Mid-Level\resources\views/front/product-detail.blade.php ENDPATH**/ ?>