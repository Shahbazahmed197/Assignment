<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">
                <?php if(empty($view)): ?> <?php if(isset($product)): ?>
                Edit
                 <?php else: ?>
                Add
                 <?php endif; ?>
                <?php else: ?>
                View <?php endif; ?> Product
            </h5>
            <a href="/products" class="close" data-dismiss="modal" aria-label="Close">
                <em class="icon ni ni-cross"></em>
            </a>
        </div>
        <div class="modal-body">
                <form enctype="multipart/form-data" <?php if(isset($product)): ?> id="productupdateForm" <?php else: ?> id="productForm" <?php endif; ?> class="form-validate is-alter">
                <?php echo csrf_field(); ?>
                 <!-- Product Name -->
        <div class="form-group">
            <label for="productName">Product Name</label>
            <input type="text" class="form-control"value="<?php if(isset($product)): ?><?php echo e($product->name); ?><?php endif; ?>"
                id="productName" name="name" required placeholder="Enter Product Name">
            <?php if(isset($product)): ?>
                <input type="text" value="<?php echo e($product->id); ?>" class="form-control" id="productid"
                    name="product_id" hidden required>
            <?php endif; ?>
        </div>
                 <!-- Product Description -->
        <div class="form-group">
            <label for="productDescription">Product Description</label>
                        <div class="form-control-wrap">
                <textarea class="form-control no-resize" name="description"  id="default-textarea"> <?php if(isset($product)): ?> <?php echo e($product->description); ?><?php endif; ?></textarea>
            </div>
        </div>
             <!-- Product Categories (Multiple Select) -->
        <?php if(isset($view)): ?>
        <div class="form-group">
            <label for="productCategories">Product Categories</label>
            <input type="text" class="form-control"
                value="<?php if(isset($product)): ?><?php echo e(implode(', ',$product->categories()->pluck('name')->toArray())); ?>

                <?php endif; ?>"
                id="productName" name="categories" required>
        </div>
        <?php else: ?>
        <div class="form-group">
            <label for="productCategories">Categories</label>
            <div class="form-control-wrap">
                <select class="form-select" multiple="multiple" name="categories[]" required
                    id="productCategories" data-placeholder="Select Multiple categories">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            <?php if(isset($product_categories)): ?> <?php if(in_array($category->id, $product_categories)): ?> selected <?php endif; ?> <?php endif; ?>
                            value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <?php endif; ?>

       <!-- Product Images (Multiple Uploads) -->
        <label for="productImages">Product Images</label>
        <?php if(empty($view)): ?>
            <div class="upload-zone" data-accepted-files="image/*">

                <div class="dz-message" data-dz-message>
                    <span class="dz-message-text">Drag and drop file</span>
                    <span class="dz-message-or">or</span>
                    <button type="button" class="btn btn-primary">SELECT</button>
                </div>
                <?php if(isset($product)): ?>
                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="dz-preview dz-processing dz-image-preview">
                    <div class="dz-image">
                        <img data-dz-thumbnail src="<?php echo e(asset('storage/' . $image->path)); ?>">
                    </div>
                    <a class="dz-remove" href="javascript:undefined;" data-dz-remove="">Remove file</a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
    <?php if(empty($view)): ?>
        <div class="form-group">
            <button type="button" class="btn btn-primary text-dark submit-btn"
                onclick="<?php if(isset($product)): ?>updateProductForm(<?php echo e($product->id); ?>) <?php else: ?> createProductForm()  <?php endif; ?>">
                Submit</button>
        </div>
    <?php endif; ?>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\LaravelAssignment-Mid-Level\resources\views/products/form.blade.php ENDPATH**/ ?>