<h4> New User Registered</h4><br>
A new user has registered with the following details: <br>
Name: <?php echo e($user->name); ?><br>
Email: <?php echo e($user->email); ?>

<br>
Thank you
<?php /**PATH D:\LaravelAssignment-Mid-Level\resources\views/emails/new_user_registered.blade.php ENDPATH**/ ?>