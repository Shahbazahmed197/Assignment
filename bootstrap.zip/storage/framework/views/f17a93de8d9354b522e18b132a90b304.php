
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php if(empty($view)): ?> <?php if(isset($category)): ?> Edit <?php else: ?> Add <?php endif; ?> <?php else: ?> View <?php endif; ?> Category</h5>
                <a  class="close" data-dismiss="modal" aria-label="Close" href="/categories">
                    <em class="icon ni ni-cross"></em>
                </a>
            </div>
            <div class="modal-body">
                    <form id="categoryForm" class="form-validate is-alter" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group">
                            <label class="form-label required" for="name">Category Name</label>
                            <div class="form-control-wrap">
                                <input type="text" class="form-control" value="<?php if(isset($category)): ?><?php echo e($category->name); ?><?php endif; ?>" name="name" required>
                            </div>
                        </div>
                    <?php if(empty($view)): ?>
                    <div class="form-group">
                        <button type="button" class="btn btn-primary text-dark submit-btn" onclick="<?php if(isset($category)): ?>submitupdatecategoryForm(<?php echo e($category->id); ?>) <?php else: ?> submitcategoryForm()  <?php endif; ?>">
                            Submit</button>
                    </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
<?php /**PATH D:\LaravelAssignment-Mid-Level\resources\views/category/form.blade.php ENDPATH**/ ?>