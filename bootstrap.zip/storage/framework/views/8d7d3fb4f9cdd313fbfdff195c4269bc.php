<?php $__env->startSection('content'); ?>
  <div class="container">
    <strong class="py-3">All Categories</strong>
    <div class="row">
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($category->name); ?></h5>
              <p class="card-text">Total Product: <?php echo e($category->products_count); ?></p>
              <a href="<?php echo e(route('products',$category->id)); ?>" class="btn btn-primary">View Products</a>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelAssignment-backup\resources\views/front/categories.blade.php ENDPATH**/ ?>