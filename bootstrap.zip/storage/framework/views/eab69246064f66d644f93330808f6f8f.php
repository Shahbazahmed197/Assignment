<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <base href="../../../">
        <meta charset="utf-8">
        <meta name="author" content="Softnio">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
        <!-- Page Title  -->
        <title><?php echo $__env->yieldContent('title'); ?> | DashLite Admin Template</title>
        <link rel="shortcut icon" href="./images/favicon.png">
        <!-- StyleSheets  -->
        <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('css/theme.css')); ?>">
        <link id="skin-default" rel="stylesheet" href="<?php echo e(asset('css/dashlite.css')); ?>">
    </head>
    <body class="nk-body bg-white npc-general pg-auth">
        <?php echo $__env->yieldContent('content'); ?>
        <script src="<?php echo e(asset('js/bundle.js')); ?>"></script>
        <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
        <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
    </body>
    <?php if(isset($errors)): ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        NioApp.Toast('<?php echo e($errors->first()); ?>', 'error');
    });
</script>
<?php endif; ?>
<?php if(session('status')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var successMessage = <?php echo json_encode(session('status'), 15, 512) ?>;
            NioApp.Toast(successMessage, 'success');
        });
    </script>
    <?php endif; ?>
</html>
<?php /**PATH D:\LaravelAssignment-Mid-Level\resources\views/layouts/guest.blade.php ENDPATH**/ ?>