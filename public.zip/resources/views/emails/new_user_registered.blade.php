<h4> New User Registered</h4><br>
A new user has registered with the following details: <br>
Email: {{ $user->email }}
<br>
Thank you
